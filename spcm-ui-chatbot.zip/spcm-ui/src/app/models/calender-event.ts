export class CalenderEvent {
  id: number;
  date: Date;
  event: string;
  isManualCalendar: boolean;
}
